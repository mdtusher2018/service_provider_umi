// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'communication_and_notification_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(NotificationsNotifier)
final notificationsProvider = NotificationsNotifierProvider._();

final class NotificationsNotifierProvider
    extends $NotifierProvider<NotificationsNotifier, NotificationListState> {
  NotificationsNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'notificationsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$notificationsNotifierHash();

  @$internal
  @override
  NotificationsNotifier create() => NotificationsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(NotificationListState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<NotificationListState>(value),
    );
  }
}

String _$notificationsNotifierHash() =>
    r'cb4c9c72d0ce55f8e018acc0134c05d4c4939ff0';

abstract class _$NotificationsNotifier
    extends $Notifier<NotificationListState> {
  NotificationListState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<NotificationListState, NotificationListState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<NotificationListState, NotificationListState>,
              NotificationListState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(MarkNotificationsNotifier)
final markNotificationsProvider = MarkNotificationsNotifierProvider._();

final class MarkNotificationsNotifierProvider
    extends
        $NotifierProvider<MarkNotificationsNotifier, NotificationActionState> {
  MarkNotificationsNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'markNotificationsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$markNotificationsNotifierHash();

  @$internal
  @override
  MarkNotificationsNotifier create() => MarkNotificationsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(NotificationActionState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<NotificationActionState>(value),
    );
  }
}

String _$markNotificationsNotifierHash() =>
    r'77840dd97d4bfd50e8901947c60eb4d910233588';

abstract class _$MarkNotificationsNotifier
    extends $Notifier<NotificationActionState> {
  NotificationActionState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref as $Ref<NotificationActionState, NotificationActionState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<NotificationActionState, NotificationActionState>,
              NotificationActionState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(DeleteNotificationsNotifier)
final deleteNotificationsProvider = DeleteNotificationsNotifierProvider._();

final class DeleteNotificationsNotifierProvider
    extends
        $NotifierProvider<
          DeleteNotificationsNotifier,
          NotificationActionState
        > {
  DeleteNotificationsNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'deleteNotificationsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$deleteNotificationsNotifierHash();

  @$internal
  @override
  DeleteNotificationsNotifier create() => DeleteNotificationsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(NotificationActionState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<NotificationActionState>(value),
    );
  }
}

String _$deleteNotificationsNotifierHash() =>
    r'd0c6843f5fe0b3eb501609e12d4dc8fb5e9f0d21';

abstract class _$DeleteNotificationsNotifier
    extends $Notifier<NotificationActionState> {
  NotificationActionState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref as $Ref<NotificationActionState, NotificationActionState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<NotificationActionState, NotificationActionState>,
              NotificationActionState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(CallHistoryNotifier)
final callHistoryProvider = CallHistoryNotifierProvider._();

final class CallHistoryNotifierProvider
    extends $NotifierProvider<CallHistoryNotifier, CallHistoryState> {
  CallHistoryNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'callHistoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$callHistoryNotifierHash();

  @$internal
  @override
  CallHistoryNotifier create() => CallHistoryNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(CallHistoryState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<CallHistoryState>(value),
    );
  }
}

String _$callHistoryNotifierHash() =>
    r'673e025811b566085cc2b0c42c738516ca965b47';

abstract class _$CallHistoryNotifier extends $Notifier<CallHistoryState> {
  CallHistoryState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<CallHistoryState, CallHistoryState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<CallHistoryState, CallHistoryState>,
              CallHistoryState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
