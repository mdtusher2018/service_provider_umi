// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'service_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(CategoriesNotifier)
final categoriesProvider = CategoriesNotifierProvider._();

final class CategoriesNotifierProvider
    extends
        $NotifierProvider<CategoriesNotifier, AsyncValue<List<CategoryModel>>> {
  CategoriesNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'categoriesProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$categoriesNotifierHash();

  @$internal
  @override
  CategoriesNotifier create() => CategoriesNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<List<CategoryModel>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<List<CategoryModel>>>(
        value,
      ),
    );
  }
}

String _$categoriesNotifierHash() =>
    r'28b400c26727961b465d7d978650317839e17c43';

abstract class _$CategoriesNotifier
    extends $Notifier<AsyncValue<List<CategoryModel>>> {
  AsyncValue<List<CategoryModel>> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<List<CategoryModel>>,
              AsyncValue<List<CategoryModel>>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<List<CategoryModel>>,
                AsyncValue<List<CategoryModel>>
              >,
              AsyncValue<List<CategoryModel>>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(SubCategoriesNotifier)
final subCategoriesProvider = SubCategoriesNotifierProvider._();

final class SubCategoriesNotifierProvider
    extends
        $NotifierProvider<
          SubCategoriesNotifier,
          AsyncValue<List<CategoryModel>>
        > {
  SubCategoriesNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'subCategoriesProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$subCategoriesNotifierHash();

  @$internal
  @override
  SubCategoriesNotifier create() => SubCategoriesNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<List<CategoryModel>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<List<CategoryModel>>>(
        value,
      ),
    );
  }
}

String _$subCategoriesNotifierHash() =>
    r'8da34a01197fbd0b4bc668a2f4b46106342cc3fd';

abstract class _$SubCategoriesNotifier
    extends $Notifier<AsyncValue<List<CategoryModel>>> {
  AsyncValue<List<CategoryModel>> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<List<CategoryModel>>,
              AsyncValue<List<CategoryModel>>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<List<CategoryModel>>,
                AsyncValue<List<CategoryModel>>
              >,
              AsyncValue<List<CategoryModel>>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(ServiceDetailsNotifier)
final serviceDetailsProvider = ServiceDetailsNotifierProvider._();

final class ServiceDetailsNotifierProvider
    extends
        $NotifierProvider<ServiceDetailsNotifier, AsyncValue<CategoryModel>> {
  ServiceDetailsNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'serviceDetailsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$serviceDetailsNotifierHash();

  @$internal
  @override
  ServiceDetailsNotifier create() => ServiceDetailsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<CategoryModel> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<CategoryModel>>(value),
    );
  }
}

String _$serviceDetailsNotifierHash() =>
    r'01a6ff7b9772739ddcf5f90197c05f1af2d24df8';

abstract class _$ServiceDetailsNotifier
    extends $Notifier<AsyncValue<CategoryModel>> {
  AsyncValue<CategoryModel> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<CategoryModel>, AsyncValue<CategoryModel>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<CategoryModel>, AsyncValue<CategoryModel>>,
              AsyncValue<CategoryModel>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(SearchServiceProvidersNotifier)
final searchServiceProvidersProvider =
    SearchServiceProvidersNotifierProvider._();

final class SearchServiceProvidersNotifierProvider
    extends
        $NotifierProvider<
          SearchServiceProvidersNotifier,
          AsyncValue<SearchProvidersResponse>
        > {
  SearchServiceProvidersNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'searchServiceProvidersProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$searchServiceProvidersNotifierHash();

  @$internal
  @override
  SearchServiceProvidersNotifier create() => SearchServiceProvidersNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<SearchProvidersResponse> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<SearchProvidersResponse>>(
        value,
      ),
    );
  }
}

String _$searchServiceProvidersNotifierHash() =>
    r'0e41cd8ec528b489d45c6d87c260a843cfab7544';

abstract class _$SearchServiceProvidersNotifier
    extends $Notifier<AsyncValue<SearchProvidersResponse>> {
  AsyncValue<SearchProvidersResponse> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<SearchProvidersResponse>,
              AsyncValue<SearchProvidersResponse>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<SearchProvidersResponse>,
                AsyncValue<SearchProvidersResponse>
              >,
              AsyncValue<SearchProvidersResponse>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(BookingsNotifier)
final bookingsProvider = BookingsNotifierFamily._();

final class BookingsNotifierProvider
    extends
        $NotifierProvider<BookingsNotifier, AsyncValue<List<BookingModel>>> {
  BookingsNotifierProvider._({
    required BookingsNotifierFamily super.from,
    required BookingStatus super.argument,
  }) : super(
         retry: null,
         name: r'bookingsProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$bookingsNotifierHash();

  @override
  String toString() {
    return r'bookingsProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  BookingsNotifier create() => BookingsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<List<BookingModel>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<List<BookingModel>>>(
        value,
      ),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is BookingsNotifierProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$bookingsNotifierHash() => r'a90b92e338e32990bba84dae9691c2feeb6830d3';

final class BookingsNotifierFamily extends $Family
    with
        $ClassFamilyOverride<
          BookingsNotifier,
          AsyncValue<List<BookingModel>>,
          AsyncValue<List<BookingModel>>,
          AsyncValue<List<BookingModel>>,
          BookingStatus
        > {
  BookingsNotifierFamily._()
    : super(
        retry: null,
        name: r'bookingsProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  BookingsNotifierProvider call(BookingStatus status) =>
      BookingsNotifierProvider._(argument: status, from: this);

  @override
  String toString() => r'bookingsProvider';
}

abstract class _$BookingsNotifier
    extends $Notifier<AsyncValue<List<BookingModel>>> {
  late final _$args = ref.$arg as BookingStatus;
  BookingStatus get status => _$args;

  AsyncValue<List<BookingModel>> build(BookingStatus status);
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<List<BookingModel>>,
              AsyncValue<List<BookingModel>>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<List<BookingModel>>,
                AsyncValue<List<BookingModel>>
              >,
              AsyncValue<List<BookingModel>>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, () => build(_$args));
  }
}

@ProviderFor(BookingDetail)
final bookingDetailProvider = BookingDetailFamily._();

final class BookingDetailProvider
    extends $AsyncNotifierProvider<BookingDetail, BookingDetailModel?> {
  BookingDetailProvider._({
    required BookingDetailFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'bookingDetailProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$bookingDetailHash();

  @override
  String toString() {
    return r'bookingDetailProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  BookingDetail create() => BookingDetail();

  @override
  bool operator ==(Object other) {
    return other is BookingDetailProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$bookingDetailHash() => r'1c45d0058848bb66e09db16f4f27537ea48d6ec1';

final class BookingDetailFamily extends $Family
    with
        $ClassFamilyOverride<
          BookingDetail,
          AsyncValue<BookingDetailModel?>,
          BookingDetailModel?,
          FutureOr<BookingDetailModel?>,
          String
        > {
  BookingDetailFamily._()
    : super(
        retry: null,
        name: r'bookingDetailProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  BookingDetailProvider call(String bookingId) =>
      BookingDetailProvider._(argument: bookingId, from: this);

  @override
  String toString() => r'bookingDetailProvider';
}

abstract class _$BookingDetail extends $AsyncNotifier<BookingDetailModel?> {
  late final _$args = ref.$arg as String;
  String get bookingId => _$args;

  FutureOr<BookingDetailModel?> build(String bookingId);
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<BookingDetailModel?>, BookingDetailModel?>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<BookingDetailModel?>, BookingDetailModel?>,
              AsyncValue<BookingDetailModel?>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, () => build(_$args));
  }
}

@ProviderFor(AcceptBooking)
final acceptBookingProvider = AcceptBookingProvider._();

final class AcceptBookingProvider
    extends $AsyncNotifierProvider<AcceptBooking, void> {
  AcceptBookingProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'acceptBookingProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$acceptBookingHash();

  @$internal
  @override
  AcceptBooking create() => AcceptBooking();
}

String _$acceptBookingHash() => r'878da30cd6696fc34b6e67d1ea48840c2d0d8f35';

abstract class _$AcceptBooking extends $AsyncNotifier<void> {
  FutureOr<void> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<AsyncValue<void>, void>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<void>, void>,
              AsyncValue<void>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(RejectBooking)
final rejectBookingProvider = RejectBookingProvider._();

final class RejectBookingProvider
    extends $AsyncNotifierProvider<RejectBooking, void> {
  RejectBookingProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'rejectBookingProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$rejectBookingHash();

  @$internal
  @override
  RejectBooking create() => RejectBooking();
}

String _$rejectBookingHash() => r'ee99af9baca7fdd4dff66409227c487138f7c835';

abstract class _$RejectBooking extends $AsyncNotifier<void> {
  FutureOr<void> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<AsyncValue<void>, void>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<void>, void>,
              AsyncValue<void>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(CompleteBooking)
final completeBookingProvider = CompleteBookingProvider._();

final class CompleteBookingProvider
    extends $AsyncNotifierProvider<CompleteBooking, void> {
  CompleteBookingProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'completeBookingProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$completeBookingHash();

  @$internal
  @override
  CompleteBooking create() => CompleteBooking();
}

String _$completeBookingHash() => r'4fb4676ca12f175f869221139c2cd866fa7a6d41';

abstract class _$CompleteBooking extends $AsyncNotifier<void> {
  FutureOr<void> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<AsyncValue<void>, void>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<void>, void>,
              AsyncValue<void>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(ConfirmPayment)
final confirmPaymentProvider = ConfirmPaymentProvider._();

final class ConfirmPaymentProvider
    extends $AsyncNotifierProvider<ConfirmPayment, void> {
  ConfirmPaymentProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'confirmPaymentProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$confirmPaymentHash();

  @$internal
  @override
  ConfirmPayment create() => ConfirmPayment();
}

String _$confirmPaymentHash() => r'7895a06efc7dc7018cfba8db5793ba388e33e2ac';

abstract class _$ConfirmPayment extends $AsyncNotifier<void> {
  FutureOr<void> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<AsyncValue<void>, void>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<void>, void>,
              AsyncValue<void>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(FaqNotifier)
final faqProvider = FaqNotifierProvider._();

final class FaqNotifierProvider
    extends $NotifierProvider<FaqNotifier, AsyncValue<List<FaqItem>>> {
  FaqNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'faqProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$faqNotifierHash();

  @$internal
  @override
  FaqNotifier create() => FaqNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<List<FaqItem>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<List<FaqItem>>>(value),
    );
  }
}

String _$faqNotifierHash() => r'cb9cb558112c764dc7f7e9428bd72f217d2f8fca';

abstract class _$FaqNotifier extends $Notifier<AsyncValue<List<FaqItem>>> {
  AsyncValue<List<FaqItem>> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<List<FaqItem>>, AsyncValue<List<FaqItem>>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<FaqItem>>, AsyncValue<List<FaqItem>>>,
              AsyncValue<List<FaqItem>>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(ProviderFaqsNotifier)
final providerFaqsProvider = ProviderFaqsNotifierFamily._();

final class ProviderFaqsNotifierProvider
    extends $NotifierProvider<ProviderFaqsNotifier, AsyncValue<List<FaqItem>>> {
  ProviderFaqsNotifierProvider._({
    required ProviderFaqsNotifierFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'providerFaqsProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$providerFaqsNotifierHash();

  @override
  String toString() {
    return r'providerFaqsProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  ProviderFaqsNotifier create() => ProviderFaqsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<List<FaqItem>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<List<FaqItem>>>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is ProviderFaqsNotifierProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$providerFaqsNotifierHash() =>
    r'9c82a9ec7755e112f12991fc4f77ca04e3916063';

final class ProviderFaqsNotifierFamily extends $Family
    with
        $ClassFamilyOverride<
          ProviderFaqsNotifier,
          AsyncValue<List<FaqItem>>,
          AsyncValue<List<FaqItem>>,
          AsyncValue<List<FaqItem>>,
          String
        > {
  ProviderFaqsNotifierFamily._()
    : super(
        retry: null,
        name: r'providerFaqsProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  ProviderFaqsNotifierProvider call(String userId) =>
      ProviderFaqsNotifierProvider._(argument: userId, from: this);

  @override
  String toString() => r'providerFaqsProvider';
}

abstract class _$ProviderFaqsNotifier
    extends $Notifier<AsyncValue<List<FaqItem>>> {
  late final _$args = ref.$arg as String;
  String get userId => _$args;

  AsyncValue<List<FaqItem>> build(String userId);
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<List<FaqItem>>, AsyncValue<List<FaqItem>>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<FaqItem>>, AsyncValue<List<FaqItem>>>,
              AsyncValue<List<FaqItem>>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, () => build(_$args));
  }
}

@ProviderFor(WorkScheduleNotifier)
final workScheduleProvider = WorkScheduleNotifierProvider._();

final class WorkScheduleNotifierProvider
    extends
        $NotifierProvider<
          WorkScheduleNotifier,
          AsyncValue<WorkScheduleListResponse>
        > {
  WorkScheduleNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'workScheduleProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$workScheduleNotifierHash();

  @$internal
  @override
  WorkScheduleNotifier create() => WorkScheduleNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<WorkScheduleListResponse> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride:
          $SyncValueProvider<AsyncValue<WorkScheduleListResponse>>(value),
    );
  }
}

String _$workScheduleNotifierHash() =>
    r'7dbb9feed788cf9845b97dbe5a4e994a727835f8';

abstract class _$WorkScheduleNotifier
    extends $Notifier<AsyncValue<WorkScheduleListResponse>> {
  AsyncValue<WorkScheduleListResponse> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<WorkScheduleListResponse>,
              AsyncValue<WorkScheduleListResponse>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<WorkScheduleListResponse>,
                AsyncValue<WorkScheduleListResponse>
              >,
              AsyncValue<WorkScheduleListResponse>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(SaveWorkScheduleNotifier)
final saveWorkScheduleProvider = SaveWorkScheduleNotifierProvider._();

final class SaveWorkScheduleNotifierProvider
    extends $NotifierProvider<SaveWorkScheduleNotifier, AsyncValue<void>> {
  SaveWorkScheduleNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'saveWorkScheduleProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$saveWorkScheduleNotifierHash();

  @$internal
  @override
  SaveWorkScheduleNotifier create() => SaveWorkScheduleNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<void> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<void>>(value),
    );
  }
}

String _$saveWorkScheduleNotifierHash() =>
    r'9432fff1ce0e78364d6eb191b531c2dd28b56595';

abstract class _$SaveWorkScheduleNotifier extends $Notifier<AsyncValue<void>> {
  AsyncValue<void> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<AsyncValue<void>, AsyncValue<void>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<void>, AsyncValue<void>>,
              AsyncValue<void>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(FilterNotifier)
final filterProvider = FilterNotifierProvider._();

final class FilterNotifierProvider
    extends $NotifierProvider<FilterNotifier, AsyncValue<ServiceFiltersModel>> {
  FilterNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'filterProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$filterNotifierHash();

  @$internal
  @override
  FilterNotifier create() => FilterNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<ServiceFiltersModel> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<ServiceFiltersModel>>(
        value,
      ),
    );
  }
}

String _$filterNotifierHash() => r'7ac70a162d35d4325b38b0a9fee5e3857611668f';

abstract class _$FilterNotifier
    extends $Notifier<AsyncValue<ServiceFiltersModel>> {
  AsyncValue<ServiceFiltersModel> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<ServiceFiltersModel>,
              AsyncValue<ServiceFiltersModel>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<ServiceFiltersModel>,
                AsyncValue<ServiceFiltersModel>
              >,
              AsyncValue<ServiceFiltersModel>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(ProviderProfileNotifier)
final providerProfileProvider = ProviderProfileNotifierProvider._();

final class ProviderProfileNotifierProvider
    extends
        $NotifierProvider<
          ProviderProfileNotifier,
          AsyncValue<(UserProfile, List<ProviderComment>, String)>
        > {
  ProviderProfileNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'providerProfileProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$providerProfileNotifierHash();

  @$internal
  @override
  ProviderProfileNotifier create() => ProviderProfileNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(
    AsyncValue<(UserProfile, List<ProviderComment>, String)> value,
  ) {
    return $ProviderOverride(
      origin: this,
      providerOverride:
          $SyncValueProvider<
            AsyncValue<(UserProfile, List<ProviderComment>, String)>
          >(value),
    );
  }
}

String _$providerProfileNotifierHash() =>
    r'361964cd74c9ca89eed40252937a3fa0b35affda';

abstract class _$ProviderProfileNotifier
    extends
        $Notifier<AsyncValue<(UserProfile, List<ProviderComment>, String)>> {
  AsyncValue<(UserProfile, List<ProviderComment>, String)> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<(UserProfile, List<ProviderComment>, String)>,
              AsyncValue<(UserProfile, List<ProviderComment>, String)>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<(UserProfile, List<ProviderComment>, String)>,
                AsyncValue<(UserProfile, List<ProviderComment>, String)>
              >,
              AsyncValue<(UserProfile, List<ProviderComment>, String)>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(UpdateProviderNotifier)
final updateProviderProvider = UpdateProviderNotifierProvider._();

final class UpdateProviderNotifierProvider
    extends $NotifierProvider<UpdateProviderNotifier, AsyncValue<bool>> {
  UpdateProviderNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'updateProviderProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$updateProviderNotifierHash();

  @$internal
  @override
  UpdateProviderNotifier create() => UpdateProviderNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<bool> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<bool>>(value),
    );
  }
}

String _$updateProviderNotifierHash() =>
    r'57421b9e6d8640bb97d302d09ae6ecacd8de4f9b';

abstract class _$UpdateProviderNotifier extends $Notifier<AsyncValue<bool>> {
  AsyncValue<bool> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<AsyncValue<bool>, AsyncValue<bool>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<bool>, AsyncValue<bool>>,
              AsyncValue<bool>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(GiveReviewNotifier)
final giveReviewProvider = GiveReviewNotifierProvider._();

final class GiveReviewNotifierProvider
    extends $AsyncNotifierProvider<GiveReviewNotifier, void> {
  GiveReviewNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'giveReviewProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$giveReviewNotifierHash();

  @$internal
  @override
  GiveReviewNotifier create() => GiveReviewNotifier();
}

String _$giveReviewNotifierHash() =>
    r'7c677f8db8e61d91b2d313245df9ab1ff43808b5';

abstract class _$GiveReviewNotifier extends $AsyncNotifier<void> {
  FutureOr<void> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<AsyncValue<void>, void>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<void>, void>,
              AsyncValue<void>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
