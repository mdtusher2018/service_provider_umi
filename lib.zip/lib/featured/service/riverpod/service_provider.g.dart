// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'service_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(CategoriesNotifier)
final categoriesProvider = CategoriesNotifierProvider._();

final class CategoriesNotifierProvider
    extends
        $NotifierProvider<CategoriesNotifier, AsyncValue<List<ServiceModel>>> {
  CategoriesNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'categoriesProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$categoriesNotifierHash();

  @$internal
  @override
  CategoriesNotifier create() => CategoriesNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<List<ServiceModel>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<List<ServiceModel>>>(
        value,
      ),
    );
  }
}

String _$categoriesNotifierHash() =>
    r'b7109fd98944b52b52961d954bdec3e31c82be10';

abstract class _$CategoriesNotifier
    extends $Notifier<AsyncValue<List<ServiceModel>>> {
  AsyncValue<List<ServiceModel>> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<List<ServiceModel>>,
              AsyncValue<List<ServiceModel>>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<List<ServiceModel>>,
                AsyncValue<List<ServiceModel>>
              >,
              AsyncValue<List<ServiceModel>>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(SubCategoriesNotifier)
final subCategoriesProvider = SubCategoriesNotifierProvider._();

final class SubCategoriesNotifierProvider
    extends
        $NotifierProvider<
          SubCategoriesNotifier,
          AsyncValue<List<ServiceModel>>
        > {
  SubCategoriesNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'subCategoriesProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$subCategoriesNotifierHash();

  @$internal
  @override
  SubCategoriesNotifier create() => SubCategoriesNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<List<ServiceModel>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<List<ServiceModel>>>(
        value,
      ),
    );
  }
}

String _$subCategoriesNotifierHash() =>
    r'862a65694196b6e798c18f60fcd874d51ed833ed';

abstract class _$SubCategoriesNotifier
    extends $Notifier<AsyncValue<List<ServiceModel>>> {
  AsyncValue<List<ServiceModel>> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<List<ServiceModel>>,
              AsyncValue<List<ServiceModel>>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<List<ServiceModel>>,
                AsyncValue<List<ServiceModel>>
              >,
              AsyncValue<List<ServiceModel>>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(ServiceDetailsNotifier)
final serviceDetailsProvider = ServiceDetailsNotifierProvider._();

final class ServiceDetailsNotifierProvider
    extends
        $NotifierProvider<ServiceDetailsNotifier, AsyncValue<ServiceModel>> {
  ServiceDetailsNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'serviceDetailsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$serviceDetailsNotifierHash();

  @$internal
  @override
  ServiceDetailsNotifier create() => ServiceDetailsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<ServiceModel> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<ServiceModel>>(value),
    );
  }
}

String _$serviceDetailsNotifierHash() =>
    r'fc33c1f8c1014b8b500a66bcf304a0bea19359b5';

abstract class _$ServiceDetailsNotifier
    extends $Notifier<AsyncValue<ServiceModel>> {
  AsyncValue<ServiceModel> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<ServiceModel>, AsyncValue<ServiceModel>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<ServiceModel>, AsyncValue<ServiceModel>>,
              AsyncValue<ServiceModel>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(SearchServiceProvidersNotifier)
final searchServiceProvidersProvider =
    SearchServiceProvidersNotifierProvider._();

final class SearchServiceProvidersNotifierProvider
    extends
        $NotifierProvider<
          SearchServiceProvidersNotifier,
          AsyncValue<SearchProvidersResponse>
        > {
  SearchServiceProvidersNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'searchServiceProvidersProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$searchServiceProvidersNotifierHash();

  @$internal
  @override
  SearchServiceProvidersNotifier create() => SearchServiceProvidersNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<SearchProvidersResponse> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<SearchProvidersResponse>>(
        value,
      ),
    );
  }
}

String _$searchServiceProvidersNotifierHash() =>
    r'224c2a2c19376383e99d4b863a203f4e00abe845';

abstract class _$SearchServiceProvidersNotifier
    extends $Notifier<AsyncValue<SearchProvidersResponse>> {
  AsyncValue<SearchProvidersResponse> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<SearchProvidersResponse>,
              AsyncValue<SearchProvidersResponse>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<SearchProvidersResponse>,
                AsyncValue<SearchProvidersResponse>
              >,
              AsyncValue<SearchProvidersResponse>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(BookingsNotifier)
final bookingsProvider = BookingsNotifierProvider._();

final class BookingsNotifierProvider
    extends
        $NotifierProvider<BookingsNotifier, AsyncValue<BookingsListResponse>> {
  BookingsNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'bookingsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$bookingsNotifierHash();

  @$internal
  @override
  BookingsNotifier create() => BookingsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<BookingsListResponse> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<BookingsListResponse>>(
        value,
      ),
    );
  }
}

String _$bookingsNotifierHash() => r'efd9714da12e60dcf460f1a2e5a3b8db8eeeefe4';

abstract class _$BookingsNotifier
    extends $Notifier<AsyncValue<BookingsListResponse>> {
  AsyncValue<BookingsListResponse> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<BookingsListResponse>,
              AsyncValue<BookingsListResponse>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<BookingsListResponse>,
                AsyncValue<BookingsListResponse>
              >,
              AsyncValue<BookingsListResponse>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(FaqNotifier)
final faqProvider = FaqNotifierProvider._();

final class FaqNotifierProvider
    extends $NotifierProvider<FaqNotifier, AsyncValue<List<FaqItem>>> {
  FaqNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'faqProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$faqNotifierHash();

  @$internal
  @override
  FaqNotifier create() => FaqNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<List<FaqItem>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<List<FaqItem>>>(value),
    );
  }
}

String _$faqNotifierHash() => r'40ead24186d1c4b750c445ea21df0772b5953a51';

abstract class _$FaqNotifier extends $Notifier<AsyncValue<List<FaqItem>>> {
  AsyncValue<List<FaqItem>> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<List<FaqItem>>, AsyncValue<List<FaqItem>>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<List<FaqItem>>, AsyncValue<List<FaqItem>>>,
              AsyncValue<List<FaqItem>>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(ProviderProfileNotifier)
final providerProfileProvider = ProviderProfileNotifierProvider._();

final class ProviderProfileNotifierProvider
    extends
        $NotifierProvider<
          ProviderProfileNotifier,
          AsyncValue<ProviderProfile>
        > {
  ProviderProfileNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'providerProfileProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$providerProfileNotifierHash();

  @$internal
  @override
  ProviderProfileNotifier create() => ProviderProfileNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<ProviderProfile> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<ProviderProfile>>(value),
    );
  }
}

String _$providerProfileNotifierHash() =>
    r'e6000fbd644f6684b93c28b021fe585e50d8ffd0';

abstract class _$ProviderProfileNotifier
    extends $Notifier<AsyncValue<ProviderProfile>> {
  AsyncValue<ProviderProfile> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<AsyncValue<ProviderProfile>, AsyncValue<ProviderProfile>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<ProviderProfile>,
                AsyncValue<ProviderProfile>
              >,
              AsyncValue<ProviderProfile>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
