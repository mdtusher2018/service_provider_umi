// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'notification_provider.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$NotificationListState {





@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is NotificationListState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'NotificationListState()';
}


}

/// @nodoc
class $NotificationListStateCopyWith<$Res>  {
$NotificationListStateCopyWith(NotificationListState _, $Res Function(NotificationListState) __);
}


/// Adds pattern-matching-related methods to [NotificationListState].
extension NotificationListStatePatterns on NotificationListState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( NotificationListInitial value)?  initial,TResult Function( NotificationListLoading value)?  loading,TResult Function( NotificationListSuccess value)?  success,TResult Function( NotificationListFailure value)?  failure,required TResult orElse(),}){
final _that = this;
switch (_that) {
case NotificationListInitial() when initial != null:
return initial(_that);case NotificationListLoading() when loading != null:
return loading(_that);case NotificationListSuccess() when success != null:
return success(_that);case NotificationListFailure() when failure != null:
return failure(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( NotificationListInitial value)  initial,required TResult Function( NotificationListLoading value)  loading,required TResult Function( NotificationListSuccess value)  success,required TResult Function( NotificationListFailure value)  failure,}){
final _that = this;
switch (_that) {
case NotificationListInitial():
return initial(_that);case NotificationListLoading():
return loading(_that);case NotificationListSuccess():
return success(_that);case NotificationListFailure():
return failure(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( NotificationListInitial value)?  initial,TResult? Function( NotificationListLoading value)?  loading,TResult? Function( NotificationListSuccess value)?  success,TResult? Function( NotificationListFailure value)?  failure,}){
final _that = this;
switch (_that) {
case NotificationListInitial() when initial != null:
return initial(_that);case NotificationListLoading() when loading != null:
return loading(_that);case NotificationListSuccess() when success != null:
return success(_that);case NotificationListFailure() when failure != null:
return failure(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function()?  loading,TResult Function( List<NotificationItem> notifications)?  success,TResult Function( Failure failure)?  failure,required TResult orElse(),}) {final _that = this;
switch (_that) {
case NotificationListInitial() when initial != null:
return initial();case NotificationListLoading() when loading != null:
return loading();case NotificationListSuccess() when success != null:
return success(_that.notifications);case NotificationListFailure() when failure != null:
return failure(_that.failure);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function()  loading,required TResult Function( List<NotificationItem> notifications)  success,required TResult Function( Failure failure)  failure,}) {final _that = this;
switch (_that) {
case NotificationListInitial():
return initial();case NotificationListLoading():
return loading();case NotificationListSuccess():
return success(_that.notifications);case NotificationListFailure():
return failure(_that.failure);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function()?  loading,TResult? Function( List<NotificationItem> notifications)?  success,TResult? Function( Failure failure)?  failure,}) {final _that = this;
switch (_that) {
case NotificationListInitial() when initial != null:
return initial();case NotificationListLoading() when loading != null:
return loading();case NotificationListSuccess() when success != null:
return success(_that.notifications);case NotificationListFailure() when failure != null:
return failure(_that.failure);case _:
  return null;

}
}

}

/// @nodoc


class NotificationListInitial implements NotificationListState {
  const NotificationListInitial();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is NotificationListInitial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'NotificationListState.initial()';
}


}




/// @nodoc


class NotificationListLoading implements NotificationListState {
  const NotificationListLoading();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is NotificationListLoading);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'NotificationListState.loading()';
}


}




/// @nodoc


class NotificationListSuccess implements NotificationListState {
  const NotificationListSuccess(final  List<NotificationItem> notifications): _notifications = notifications;
  

 final  List<NotificationItem> _notifications;
 List<NotificationItem> get notifications {
  if (_notifications is EqualUnmodifiableListView) return _notifications;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_notifications);
}


/// Create a copy of NotificationListState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$NotificationListSuccessCopyWith<NotificationListSuccess> get copyWith => _$NotificationListSuccessCopyWithImpl<NotificationListSuccess>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is NotificationListSuccess&&const DeepCollectionEquality().equals(other._notifications, _notifications));
}


@override
int get hashCode => Object.hash(runtimeType,const DeepCollectionEquality().hash(_notifications));

@override
String toString() {
  return 'NotificationListState.success(notifications: $notifications)';
}


}

/// @nodoc
abstract mixin class $NotificationListSuccessCopyWith<$Res> implements $NotificationListStateCopyWith<$Res> {
  factory $NotificationListSuccessCopyWith(NotificationListSuccess value, $Res Function(NotificationListSuccess) _then) = _$NotificationListSuccessCopyWithImpl;
@useResult
$Res call({
 List<NotificationItem> notifications
});




}
/// @nodoc
class _$NotificationListSuccessCopyWithImpl<$Res>
    implements $NotificationListSuccessCopyWith<$Res> {
  _$NotificationListSuccessCopyWithImpl(this._self, this._then);

  final NotificationListSuccess _self;
  final $Res Function(NotificationListSuccess) _then;

/// Create a copy of NotificationListState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? notifications = null,}) {
  return _then(NotificationListSuccess(
null == notifications ? _self._notifications : notifications // ignore: cast_nullable_to_non_nullable
as List<NotificationItem>,
  ));
}


}

/// @nodoc


class NotificationListFailure implements NotificationListState {
  const NotificationListFailure(this.failure);
  

 final  Failure failure;

/// Create a copy of NotificationListState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$NotificationListFailureCopyWith<NotificationListFailure> get copyWith => _$NotificationListFailureCopyWithImpl<NotificationListFailure>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is NotificationListFailure&&(identical(other.failure, failure) || other.failure == failure));
}


@override
int get hashCode => Object.hash(runtimeType,failure);

@override
String toString() {
  return 'NotificationListState.failure(failure: $failure)';
}


}

/// @nodoc
abstract mixin class $NotificationListFailureCopyWith<$Res> implements $NotificationListStateCopyWith<$Res> {
  factory $NotificationListFailureCopyWith(NotificationListFailure value, $Res Function(NotificationListFailure) _then) = _$NotificationListFailureCopyWithImpl;
@useResult
$Res call({
 Failure failure
});


$FailureCopyWith<$Res> get failure;

}
/// @nodoc
class _$NotificationListFailureCopyWithImpl<$Res>
    implements $NotificationListFailureCopyWith<$Res> {
  _$NotificationListFailureCopyWithImpl(this._self, this._then);

  final NotificationListFailure _self;
  final $Res Function(NotificationListFailure) _then;

/// Create a copy of NotificationListState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? failure = null,}) {
  return _then(NotificationListFailure(
null == failure ? _self.failure : failure // ignore: cast_nullable_to_non_nullable
as Failure,
  ));
}

/// Create a copy of NotificationListState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$FailureCopyWith<$Res> get failure {
  
  return $FailureCopyWith<$Res>(_self.failure, (value) {
    return _then(_self.copyWith(failure: value));
  });
}
}

/// @nodoc
mixin _$NotificationActionState {





@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is NotificationActionState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'NotificationActionState()';
}


}

/// @nodoc
class $NotificationActionStateCopyWith<$Res>  {
$NotificationActionStateCopyWith(NotificationActionState _, $Res Function(NotificationActionState) __);
}


/// Adds pattern-matching-related methods to [NotificationActionState].
extension NotificationActionStatePatterns on NotificationActionState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( NotificationActionInitial value)?  initial,TResult Function( NotificationActionLoading value)?  loading,TResult Function( NotificationActionSuccess value)?  success,TResult Function( NotificationActionFailure value)?  failure,required TResult orElse(),}){
final _that = this;
switch (_that) {
case NotificationActionInitial() when initial != null:
return initial(_that);case NotificationActionLoading() when loading != null:
return loading(_that);case NotificationActionSuccess() when success != null:
return success(_that);case NotificationActionFailure() when failure != null:
return failure(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( NotificationActionInitial value)  initial,required TResult Function( NotificationActionLoading value)  loading,required TResult Function( NotificationActionSuccess value)  success,required TResult Function( NotificationActionFailure value)  failure,}){
final _that = this;
switch (_that) {
case NotificationActionInitial():
return initial(_that);case NotificationActionLoading():
return loading(_that);case NotificationActionSuccess():
return success(_that);case NotificationActionFailure():
return failure(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( NotificationActionInitial value)?  initial,TResult? Function( NotificationActionLoading value)?  loading,TResult? Function( NotificationActionSuccess value)?  success,TResult? Function( NotificationActionFailure value)?  failure,}){
final _that = this;
switch (_that) {
case NotificationActionInitial() when initial != null:
return initial(_that);case NotificationActionLoading() when loading != null:
return loading(_that);case NotificationActionSuccess() when success != null:
return success(_that);case NotificationActionFailure() when failure != null:
return failure(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function()?  loading,TResult Function()?  success,TResult Function( Failure failure)?  failure,required TResult orElse(),}) {final _that = this;
switch (_that) {
case NotificationActionInitial() when initial != null:
return initial();case NotificationActionLoading() when loading != null:
return loading();case NotificationActionSuccess() when success != null:
return success();case NotificationActionFailure() when failure != null:
return failure(_that.failure);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function()  loading,required TResult Function()  success,required TResult Function( Failure failure)  failure,}) {final _that = this;
switch (_that) {
case NotificationActionInitial():
return initial();case NotificationActionLoading():
return loading();case NotificationActionSuccess():
return success();case NotificationActionFailure():
return failure(_that.failure);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function()?  loading,TResult? Function()?  success,TResult? Function( Failure failure)?  failure,}) {final _that = this;
switch (_that) {
case NotificationActionInitial() when initial != null:
return initial();case NotificationActionLoading() when loading != null:
return loading();case NotificationActionSuccess() when success != null:
return success();case NotificationActionFailure() when failure != null:
return failure(_that.failure);case _:
  return null;

}
}

}

/// @nodoc


class NotificationActionInitial implements NotificationActionState {
  const NotificationActionInitial();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is NotificationActionInitial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'NotificationActionState.initial()';
}


}




/// @nodoc


class NotificationActionLoading implements NotificationActionState {
  const NotificationActionLoading();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is NotificationActionLoading);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'NotificationActionState.loading()';
}


}




/// @nodoc


class NotificationActionSuccess implements NotificationActionState {
  const NotificationActionSuccess();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is NotificationActionSuccess);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'NotificationActionState.success()';
}


}




/// @nodoc


class NotificationActionFailure implements NotificationActionState {
  const NotificationActionFailure(this.failure);
  

 final  Failure failure;

/// Create a copy of NotificationActionState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$NotificationActionFailureCopyWith<NotificationActionFailure> get copyWith => _$NotificationActionFailureCopyWithImpl<NotificationActionFailure>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is NotificationActionFailure&&(identical(other.failure, failure) || other.failure == failure));
}


@override
int get hashCode => Object.hash(runtimeType,failure);

@override
String toString() {
  return 'NotificationActionState.failure(failure: $failure)';
}


}

/// @nodoc
abstract mixin class $NotificationActionFailureCopyWith<$Res> implements $NotificationActionStateCopyWith<$Res> {
  factory $NotificationActionFailureCopyWith(NotificationActionFailure value, $Res Function(NotificationActionFailure) _then) = _$NotificationActionFailureCopyWithImpl;
@useResult
$Res call({
 Failure failure
});


$FailureCopyWith<$Res> get failure;

}
/// @nodoc
class _$NotificationActionFailureCopyWithImpl<$Res>
    implements $NotificationActionFailureCopyWith<$Res> {
  _$NotificationActionFailureCopyWithImpl(this._self, this._then);

  final NotificationActionFailure _self;
  final $Res Function(NotificationActionFailure) _then;

/// Create a copy of NotificationActionState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? failure = null,}) {
  return _then(NotificationActionFailure(
null == failure ? _self.failure : failure // ignore: cast_nullable_to_non_nullable
as Failure,
  ));
}

/// Create a copy of NotificationActionState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$FailureCopyWith<$Res> get failure {
  
  return $FailureCopyWith<$Res>(_self.failure, (value) {
    return _then(_self.copyWith(failure: value));
  });
}
}

// dart format on
