// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notification_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(NotificationsNotifier)
final notificationsProvider = NotificationsNotifierProvider._();

final class NotificationsNotifierProvider
    extends $NotifierProvider<NotificationsNotifier, NotificationListState> {
  NotificationsNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'notificationsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$notificationsNotifierHash();

  @$internal
  @override
  NotificationsNotifier create() => NotificationsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(NotificationListState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<NotificationListState>(value),
    );
  }
}

String _$notificationsNotifierHash() =>
    r'618f923edd0d372deaf5cb3cf3949fd051a36c21';

abstract class _$NotificationsNotifier
    extends $Notifier<NotificationListState> {
  NotificationListState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<NotificationListState, NotificationListState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<NotificationListState, NotificationListState>,
              NotificationListState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(MarkNotificationsNotifier)
final markNotificationsProvider = MarkNotificationsNotifierProvider._();

final class MarkNotificationsNotifierProvider
    extends
        $NotifierProvider<MarkNotificationsNotifier, NotificationActionState> {
  MarkNotificationsNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'markNotificationsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$markNotificationsNotifierHash();

  @$internal
  @override
  MarkNotificationsNotifier create() => MarkNotificationsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(NotificationActionState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<NotificationActionState>(value),
    );
  }
}

String _$markNotificationsNotifierHash() =>
    r'e907636642c0af037c834cd0db5a2d054c0683d6';

abstract class _$MarkNotificationsNotifier
    extends $Notifier<NotificationActionState> {
  NotificationActionState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref as $Ref<NotificationActionState, NotificationActionState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<NotificationActionState, NotificationActionState>,
              NotificationActionState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(DeleteNotificationsNotifier)
final deleteNotificationsProvider = DeleteNotificationsNotifierProvider._();

final class DeleteNotificationsNotifierProvider
    extends
        $NotifierProvider<
          DeleteNotificationsNotifier,
          NotificationActionState
        > {
  DeleteNotificationsNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'deleteNotificationsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$deleteNotificationsNotifierHash();

  @$internal
  @override
  DeleteNotificationsNotifier create() => DeleteNotificationsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(NotificationActionState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<NotificationActionState>(value),
    );
  }
}

String _$deleteNotificationsNotifierHash() =>
    r'2c77499bd09da66e731dfcbf75015d73b45a7b4a';

abstract class _$DeleteNotificationsNotifier
    extends $Notifier<NotificationActionState> {
  NotificationActionState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref as $Ref<NotificationActionState, NotificationActionState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<NotificationActionState, NotificationActionState>,
              NotificationActionState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
