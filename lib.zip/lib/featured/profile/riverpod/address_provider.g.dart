// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'address_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(AddressNotifier)
final addressProvider = AddressNotifierProvider._();

final class AddressNotifierProvider
    extends $NotifierProvider<AddressNotifier, AsyncValue<List<AddressModel>>> {
  AddressNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'addressProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$addressNotifierHash();

  @$internal
  @override
  AddressNotifier create() => AddressNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<List<AddressModel>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<List<AddressModel>>>(
        value,
      ),
    );
  }
}

String _$addressNotifierHash() => r'1676159d6ab1f1f97b62b8ee252e1b875c414db6';

abstract class _$AddressNotifier
    extends $Notifier<AsyncValue<List<AddressModel>>> {
  AsyncValue<List<AddressModel>> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<List<AddressModel>>,
              AsyncValue<List<AddressModel>>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<List<AddressModel>>,
                AsyncValue<List<AddressModel>>
              >,
              AsyncValue<List<AddressModel>>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
