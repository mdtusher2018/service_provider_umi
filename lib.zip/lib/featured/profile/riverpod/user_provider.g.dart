// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(GetUserByIdNotifier)
final getUserByIdProvider = GetUserByIdNotifierProvider._();

final class GetUserByIdNotifierProvider
    extends $NotifierProvider<GetUserByIdNotifier, UserState> {
  GetUserByIdNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'getUserByIdProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$getUserByIdNotifierHash();

  @$internal
  @override
  GetUserByIdNotifier create() => GetUserByIdNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(UserState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<UserState>(value),
    );
  }
}

String _$getUserByIdNotifierHash() =>
    r'df496b92a3443e6708d2a288961b2feb1f7eafc9';

abstract class _$GetUserByIdNotifier extends $Notifier<UserState> {
  UserState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<UserState, UserState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<UserState, UserState>,
              UserState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(MyProfileNotifier)
final myProfileProvider = MyProfileNotifierProvider._();

final class MyProfileNotifierProvider
    extends $NotifierProvider<MyProfileNotifier, UserState> {
  MyProfileNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'myProfileProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$myProfileNotifierHash();

  @$internal
  @override
  MyProfileNotifier create() => MyProfileNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(UserState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<UserState>(value),
    );
  }
}

String _$myProfileNotifierHash() => r'1003fb4b4c7d58bffe58dcd1e12daef6f757ae0e';

abstract class _$MyProfileNotifier extends $Notifier<UserState> {
  UserState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<UserState, UserState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<UserState, UserState>,
              UserState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(UpdateProfileNotifier)
final updateProfileProvider = UpdateProfileNotifierProvider._();

final class UpdateProfileNotifierProvider
    extends $NotifierProvider<UpdateProfileNotifier, UserState> {
  UpdateProfileNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'updateProfileProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$updateProfileNotifierHash();

  @$internal
  @override
  UpdateProfileNotifier create() => UpdateProfileNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(UserState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<UserState>(value),
    );
  }
}

String _$updateProfileNotifierHash() =>
    r'ca79318fa5ef4ebd2339d6d1b8422a843bddc994';

abstract class _$UpdateProfileNotifier extends $Notifier<UserState> {
  UserState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<UserState, UserState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<UserState, UserState>,
              UserState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}

@ProviderFor(DeleteAccountNotifier)
final deleteAccountProvider = DeleteAccountNotifierProvider._();

final class DeleteAccountNotifierProvider
    extends $NotifierProvider<DeleteAccountNotifier, ActionState> {
  DeleteAccountNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'deleteAccountProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$deleteAccountNotifierHash();

  @$internal
  @override
  DeleteAccountNotifier create() => DeleteAccountNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ActionState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ActionState>(value),
    );
  }
}

String _$deleteAccountNotifierHash() =>
    r'3be3042f3c58434b66470c0d73d451495ba0f9ef';

abstract class _$DeleteAccountNotifier extends $Notifier<ActionState> {
  ActionState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<ActionState, ActionState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<ActionState, ActionState>,
              ActionState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
