// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'static_content_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(StaticContentNotifier)
final staticContentProvider = StaticContentNotifierProvider._();

final class StaticContentNotifierProvider
    extends $NotifierProvider<StaticContentNotifier, StaticContentState> {
  StaticContentNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'staticContentProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$staticContentNotifierHash();

  @$internal
  @override
  StaticContentNotifier create() => StaticContentNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(StaticContentState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<StaticContentState>(value),
    );
  }
}

String _$staticContentNotifierHash() =>
    r'210916646c1fd35f92d99c7219ad9343ac1908ac';

abstract class _$StaticContentNotifier extends $Notifier<StaticContentState> {
  StaticContentState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<StaticContentState, StaticContentState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<StaticContentState, StaticContentState>,
              StaticContentState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
