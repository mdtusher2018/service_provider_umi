// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'static_content_provider.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$StaticContentState {





@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is StaticContentState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'StaticContentState()';
}


}

/// @nodoc
class $StaticContentStateCopyWith<$Res>  {
$StaticContentStateCopyWith(StaticContentState _, $Res Function(StaticContentState) __);
}


/// Adds pattern-matching-related methods to [StaticContentState].
extension StaticContentStatePatterns on StaticContentState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( StaticContentStateInitial value)?  initial,TResult Function( StaticContentStateLoading value)?  loading,TResult Function( StaticContentStateSuccess value)?  success,TResult Function( StaticContentStateFailure value)?  failure,required TResult orElse(),}){
final _that = this;
switch (_that) {
case StaticContentStateInitial() when initial != null:
return initial(_that);case StaticContentStateLoading() when loading != null:
return loading(_that);case StaticContentStateSuccess() when success != null:
return success(_that);case StaticContentStateFailure() when failure != null:
return failure(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( StaticContentStateInitial value)  initial,required TResult Function( StaticContentStateLoading value)  loading,required TResult Function( StaticContentStateSuccess value)  success,required TResult Function( StaticContentStateFailure value)  failure,}){
final _that = this;
switch (_that) {
case StaticContentStateInitial():
return initial(_that);case StaticContentStateLoading():
return loading(_that);case StaticContentStateSuccess():
return success(_that);case StaticContentStateFailure():
return failure(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( StaticContentStateInitial value)?  initial,TResult? Function( StaticContentStateLoading value)?  loading,TResult? Function( StaticContentStateSuccess value)?  success,TResult? Function( StaticContentStateFailure value)?  failure,}){
final _that = this;
switch (_that) {
case StaticContentStateInitial() when initial != null:
return initial(_that);case StaticContentStateLoading() when loading != null:
return loading(_that);case StaticContentStateSuccess() when success != null:
return success(_that);case StaticContentStateFailure() when failure != null:
return failure(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function()?  loading,TResult Function( StaticContentItem content)?  success,TResult Function( Failure failure)?  failure,required TResult orElse(),}) {final _that = this;
switch (_that) {
case StaticContentStateInitial() when initial != null:
return initial();case StaticContentStateLoading() when loading != null:
return loading();case StaticContentStateSuccess() when success != null:
return success(_that.content);case StaticContentStateFailure() when failure != null:
return failure(_that.failure);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function()  loading,required TResult Function( StaticContentItem content)  success,required TResult Function( Failure failure)  failure,}) {final _that = this;
switch (_that) {
case StaticContentStateInitial():
return initial();case StaticContentStateLoading():
return loading();case StaticContentStateSuccess():
return success(_that.content);case StaticContentStateFailure():
return failure(_that.failure);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function()?  loading,TResult? Function( StaticContentItem content)?  success,TResult? Function( Failure failure)?  failure,}) {final _that = this;
switch (_that) {
case StaticContentStateInitial() when initial != null:
return initial();case StaticContentStateLoading() when loading != null:
return loading();case StaticContentStateSuccess() when success != null:
return success(_that.content);case StaticContentStateFailure() when failure != null:
return failure(_that.failure);case _:
  return null;

}
}

}

/// @nodoc


class StaticContentStateInitial implements StaticContentState {
  const StaticContentStateInitial();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is StaticContentStateInitial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'StaticContentState.initial()';
}


}




/// @nodoc


class StaticContentStateLoading implements StaticContentState {
  const StaticContentStateLoading();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is StaticContentStateLoading);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'StaticContentState.loading()';
}


}




/// @nodoc


class StaticContentStateSuccess implements StaticContentState {
  const StaticContentStateSuccess(this.content);
  

 final  StaticContentItem content;

/// Create a copy of StaticContentState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$StaticContentStateSuccessCopyWith<StaticContentStateSuccess> get copyWith => _$StaticContentStateSuccessCopyWithImpl<StaticContentStateSuccess>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is StaticContentStateSuccess&&(identical(other.content, content) || other.content == content));
}


@override
int get hashCode => Object.hash(runtimeType,content);

@override
String toString() {
  return 'StaticContentState.success(content: $content)';
}


}

/// @nodoc
abstract mixin class $StaticContentStateSuccessCopyWith<$Res> implements $StaticContentStateCopyWith<$Res> {
  factory $StaticContentStateSuccessCopyWith(StaticContentStateSuccess value, $Res Function(StaticContentStateSuccess) _then) = _$StaticContentStateSuccessCopyWithImpl;
@useResult
$Res call({
 StaticContentItem content
});




}
/// @nodoc
class _$StaticContentStateSuccessCopyWithImpl<$Res>
    implements $StaticContentStateSuccessCopyWith<$Res> {
  _$StaticContentStateSuccessCopyWithImpl(this._self, this._then);

  final StaticContentStateSuccess _self;
  final $Res Function(StaticContentStateSuccess) _then;

/// Create a copy of StaticContentState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? content = null,}) {
  return _then(StaticContentStateSuccess(
null == content ? _self.content : content // ignore: cast_nullable_to_non_nullable
as StaticContentItem,
  ));
}


}

/// @nodoc


class StaticContentStateFailure implements StaticContentState {
  const StaticContentStateFailure(this.failure);
  

 final  Failure failure;

/// Create a copy of StaticContentState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$StaticContentStateFailureCopyWith<StaticContentStateFailure> get copyWith => _$StaticContentStateFailureCopyWithImpl<StaticContentStateFailure>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is StaticContentStateFailure&&(identical(other.failure, failure) || other.failure == failure));
}


@override
int get hashCode => Object.hash(runtimeType,failure);

@override
String toString() {
  return 'StaticContentState.failure(failure: $failure)';
}


}

/// @nodoc
abstract mixin class $StaticContentStateFailureCopyWith<$Res> implements $StaticContentStateCopyWith<$Res> {
  factory $StaticContentStateFailureCopyWith(StaticContentStateFailure value, $Res Function(StaticContentStateFailure) _then) = _$StaticContentStateFailureCopyWithImpl;
@useResult
$Res call({
 Failure failure
});


$FailureCopyWith<$Res> get failure;

}
/// @nodoc
class _$StaticContentStateFailureCopyWithImpl<$Res>
    implements $StaticContentStateFailureCopyWith<$Res> {
  _$StaticContentStateFailureCopyWithImpl(this._self, this._then);

  final StaticContentStateFailure _self;
  final $Res Function(StaticContentStateFailure) _then;

/// Create a copy of StaticContentState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? failure = null,}) {
  return _then(StaticContentStateFailure(
null == failure ? _self.failure : failure // ignore: cast_nullable_to_non_nullable
as Failure,
  ));
}

/// Create a copy of StaticContentState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$FailureCopyWith<$Res> get failure {
  
  return $FailureCopyWith<$Res>(_self.failure, (value) {
    return _then(_self.copyWith(failure: value));
  });
}
}

// dart format on
