// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'payment_cards_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(PaymentCardsNotifier)
final paymentCardsProvider = PaymentCardsNotifierProvider._();

final class PaymentCardsNotifierProvider
    extends
        $NotifierProvider<
          PaymentCardsNotifier,
          AsyncValue<List<PaymentCardModel>>
        > {
  PaymentCardsNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'paymentCardsProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$paymentCardsNotifierHash();

  @$internal
  @override
  PaymentCardsNotifier create() => PaymentCardsNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<List<PaymentCardModel>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<List<PaymentCardModel>>>(
        value,
      ),
    );
  }
}

String _$paymentCardsNotifierHash() =>
    r'e0428a3926215e6f48f1df96386346cadaff72a1';

abstract class _$PaymentCardsNotifier
    extends $Notifier<AsyncValue<List<PaymentCardModel>>> {
  AsyncValue<List<PaymentCardModel>> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<List<PaymentCardModel>>,
              AsyncValue<List<PaymentCardModel>>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<List<PaymentCardModel>>,
                AsyncValue<List<PaymentCardModel>>
              >,
              AsyncValue<List<PaymentCardModel>>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
