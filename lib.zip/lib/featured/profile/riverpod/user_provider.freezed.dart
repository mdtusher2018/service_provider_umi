// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_provider.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$UserState {





@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is UserState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'UserState()';
}


}

/// @nodoc
class $UserStateCopyWith<$Res>  {
$UserStateCopyWith(UserState _, $Res Function(UserState) __);
}


/// Adds pattern-matching-related methods to [UserState].
extension UserStatePatterns on UserState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( UserStateInitial value)?  initial,TResult Function( UserStateLoading value)?  loading,TResult Function( UserStateSuccess value)?  success,TResult Function( UserStateFailure value)?  failure,required TResult orElse(),}){
final _that = this;
switch (_that) {
case UserStateInitial() when initial != null:
return initial(_that);case UserStateLoading() when loading != null:
return loading(_that);case UserStateSuccess() when success != null:
return success(_that);case UserStateFailure() when failure != null:
return failure(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( UserStateInitial value)  initial,required TResult Function( UserStateLoading value)  loading,required TResult Function( UserStateSuccess value)  success,required TResult Function( UserStateFailure value)  failure,}){
final _that = this;
switch (_that) {
case UserStateInitial():
return initial(_that);case UserStateLoading():
return loading(_that);case UserStateSuccess():
return success(_that);case UserStateFailure():
return failure(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( UserStateInitial value)?  initial,TResult? Function( UserStateLoading value)?  loading,TResult? Function( UserStateSuccess value)?  success,TResult? Function( UserStateFailure value)?  failure,}){
final _that = this;
switch (_that) {
case UserStateInitial() when initial != null:
return initial(_that);case UserStateLoading() when loading != null:
return loading(_that);case UserStateSuccess() when success != null:
return success(_that);case UserStateFailure() when failure != null:
return failure(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function()?  loading,TResult Function( UserProfile profile)?  success,TResult Function( Failure failure)?  failure,required TResult orElse(),}) {final _that = this;
switch (_that) {
case UserStateInitial() when initial != null:
return initial();case UserStateLoading() when loading != null:
return loading();case UserStateSuccess() when success != null:
return success(_that.profile);case UserStateFailure() when failure != null:
return failure(_that.failure);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function()  loading,required TResult Function( UserProfile profile)  success,required TResult Function( Failure failure)  failure,}) {final _that = this;
switch (_that) {
case UserStateInitial():
return initial();case UserStateLoading():
return loading();case UserStateSuccess():
return success(_that.profile);case UserStateFailure():
return failure(_that.failure);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function()?  loading,TResult? Function( UserProfile profile)?  success,TResult? Function( Failure failure)?  failure,}) {final _that = this;
switch (_that) {
case UserStateInitial() when initial != null:
return initial();case UserStateLoading() when loading != null:
return loading();case UserStateSuccess() when success != null:
return success(_that.profile);case UserStateFailure() when failure != null:
return failure(_that.failure);case _:
  return null;

}
}

}

/// @nodoc


class UserStateInitial implements UserState {
  const UserStateInitial();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is UserStateInitial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'UserState.initial()';
}


}




/// @nodoc


class UserStateLoading implements UserState {
  const UserStateLoading();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is UserStateLoading);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'UserState.loading()';
}


}




/// @nodoc


class UserStateSuccess implements UserState {
  const UserStateSuccess(this.profile);
  

 final  UserProfile profile;

/// Create a copy of UserState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$UserStateSuccessCopyWith<UserStateSuccess> get copyWith => _$UserStateSuccessCopyWithImpl<UserStateSuccess>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is UserStateSuccess&&(identical(other.profile, profile) || other.profile == profile));
}


@override
int get hashCode => Object.hash(runtimeType,profile);

@override
String toString() {
  return 'UserState.success(profile: $profile)';
}


}

/// @nodoc
abstract mixin class $UserStateSuccessCopyWith<$Res> implements $UserStateCopyWith<$Res> {
  factory $UserStateSuccessCopyWith(UserStateSuccess value, $Res Function(UserStateSuccess) _then) = _$UserStateSuccessCopyWithImpl;
@useResult
$Res call({
 UserProfile profile
});




}
/// @nodoc
class _$UserStateSuccessCopyWithImpl<$Res>
    implements $UserStateSuccessCopyWith<$Res> {
  _$UserStateSuccessCopyWithImpl(this._self, this._then);

  final UserStateSuccess _self;
  final $Res Function(UserStateSuccess) _then;

/// Create a copy of UserState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? profile = null,}) {
  return _then(UserStateSuccess(
null == profile ? _self.profile : profile // ignore: cast_nullable_to_non_nullable
as UserProfile,
  ));
}


}

/// @nodoc


class UserStateFailure implements UserState {
  const UserStateFailure(this.failure);
  

 final  Failure failure;

/// Create a copy of UserState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$UserStateFailureCopyWith<UserStateFailure> get copyWith => _$UserStateFailureCopyWithImpl<UserStateFailure>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is UserStateFailure&&(identical(other.failure, failure) || other.failure == failure));
}


@override
int get hashCode => Object.hash(runtimeType,failure);

@override
String toString() {
  return 'UserState.failure(failure: $failure)';
}


}

/// @nodoc
abstract mixin class $UserStateFailureCopyWith<$Res> implements $UserStateCopyWith<$Res> {
  factory $UserStateFailureCopyWith(UserStateFailure value, $Res Function(UserStateFailure) _then) = _$UserStateFailureCopyWithImpl;
@useResult
$Res call({
 Failure failure
});


$FailureCopyWith<$Res> get failure;

}
/// @nodoc
class _$UserStateFailureCopyWithImpl<$Res>
    implements $UserStateFailureCopyWith<$Res> {
  _$UserStateFailureCopyWithImpl(this._self, this._then);

  final UserStateFailure _self;
  final $Res Function(UserStateFailure) _then;

/// Create a copy of UserState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? failure = null,}) {
  return _then(UserStateFailure(
null == failure ? _self.failure : failure // ignore: cast_nullable_to_non_nullable
as Failure,
  ));
}

/// Create a copy of UserState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$FailureCopyWith<$Res> get failure {
  
  return $FailureCopyWith<$Res>(_self.failure, (value) {
    return _then(_self.copyWith(failure: value));
  });
}
}

/// @nodoc
mixin _$ActionState {





@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is ActionState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'ActionState()';
}


}

/// @nodoc
class $ActionStateCopyWith<$Res>  {
$ActionStateCopyWith(ActionState _, $Res Function(ActionState) __);
}


/// Adds pattern-matching-related methods to [ActionState].
extension ActionStatePatterns on ActionState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( ActionStateInitial value)?  initial,TResult Function( ActionStateLoading value)?  loading,TResult Function( ActionStateSuccess value)?  success,TResult Function( ActionStateFailure value)?  failure,required TResult orElse(),}){
final _that = this;
switch (_that) {
case ActionStateInitial() when initial != null:
return initial(_that);case ActionStateLoading() when loading != null:
return loading(_that);case ActionStateSuccess() when success != null:
return success(_that);case ActionStateFailure() when failure != null:
return failure(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( ActionStateInitial value)  initial,required TResult Function( ActionStateLoading value)  loading,required TResult Function( ActionStateSuccess value)  success,required TResult Function( ActionStateFailure value)  failure,}){
final _that = this;
switch (_that) {
case ActionStateInitial():
return initial(_that);case ActionStateLoading():
return loading(_that);case ActionStateSuccess():
return success(_that);case ActionStateFailure():
return failure(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( ActionStateInitial value)?  initial,TResult? Function( ActionStateLoading value)?  loading,TResult? Function( ActionStateSuccess value)?  success,TResult? Function( ActionStateFailure value)?  failure,}){
final _that = this;
switch (_that) {
case ActionStateInitial() when initial != null:
return initial(_that);case ActionStateLoading() when loading != null:
return loading(_that);case ActionStateSuccess() when success != null:
return success(_that);case ActionStateFailure() when failure != null:
return failure(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function()?  loading,TResult Function()?  success,TResult Function( Failure failure)?  failure,required TResult orElse(),}) {final _that = this;
switch (_that) {
case ActionStateInitial() when initial != null:
return initial();case ActionStateLoading() when loading != null:
return loading();case ActionStateSuccess() when success != null:
return success();case ActionStateFailure() when failure != null:
return failure(_that.failure);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function()  loading,required TResult Function()  success,required TResult Function( Failure failure)  failure,}) {final _that = this;
switch (_that) {
case ActionStateInitial():
return initial();case ActionStateLoading():
return loading();case ActionStateSuccess():
return success();case ActionStateFailure():
return failure(_that.failure);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function()?  loading,TResult? Function()?  success,TResult? Function( Failure failure)?  failure,}) {final _that = this;
switch (_that) {
case ActionStateInitial() when initial != null:
return initial();case ActionStateLoading() when loading != null:
return loading();case ActionStateSuccess() when success != null:
return success();case ActionStateFailure() when failure != null:
return failure(_that.failure);case _:
  return null;

}
}

}

/// @nodoc


class ActionStateInitial implements ActionState {
  const ActionStateInitial();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is ActionStateInitial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'ActionState.initial()';
}


}




/// @nodoc


class ActionStateLoading implements ActionState {
  const ActionStateLoading();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is ActionStateLoading);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'ActionState.loading()';
}


}




/// @nodoc


class ActionStateSuccess implements ActionState {
  const ActionStateSuccess();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is ActionStateSuccess);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'ActionState.success()';
}


}




/// @nodoc


class ActionStateFailure implements ActionState {
  const ActionStateFailure(this.failure);
  

 final  Failure failure;

/// Create a copy of ActionState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$ActionStateFailureCopyWith<ActionStateFailure> get copyWith => _$ActionStateFailureCopyWithImpl<ActionStateFailure>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is ActionStateFailure&&(identical(other.failure, failure) || other.failure == failure));
}


@override
int get hashCode => Object.hash(runtimeType,failure);

@override
String toString() {
  return 'ActionState.failure(failure: $failure)';
}


}

/// @nodoc
abstract mixin class $ActionStateFailureCopyWith<$Res> implements $ActionStateCopyWith<$Res> {
  factory $ActionStateFailureCopyWith(ActionStateFailure value, $Res Function(ActionStateFailure) _then) = _$ActionStateFailureCopyWithImpl;
@useResult
$Res call({
 Failure failure
});


$FailureCopyWith<$Res> get failure;

}
/// @nodoc
class _$ActionStateFailureCopyWithImpl<$Res>
    implements $ActionStateFailureCopyWith<$Res> {
  _$ActionStateFailureCopyWithImpl(this._self, this._then);

  final ActionStateFailure _self;
  final $Res Function(ActionStateFailure) _then;

/// Create a copy of ActionState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? failure = null,}) {
  return _then(ActionStateFailure(
null == failure ? _self.failure : failure // ignore: cast_nullable_to_non_nullable
as Failure,
  ));
}

/// Create a copy of ActionState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$FailureCopyWith<$Res> get failure {
  
  return $FailureCopyWith<$Res>(_self.failure, (value) {
    return _then(_self.copyWith(failure: value));
  });
}
}

/// @nodoc
mixin _$StripeConnectState {





@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is StripeConnectState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'StripeConnectState()';
}


}

/// @nodoc
class $StripeConnectStateCopyWith<$Res>  {
$StripeConnectStateCopyWith(StripeConnectState _, $Res Function(StripeConnectState) __);
}


/// Adds pattern-matching-related methods to [StripeConnectState].
extension StripeConnectStatePatterns on StripeConnectState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( StripeConnectStateInitial value)?  initial,TResult Function( StripeConnectStateLoading value)?  loading,TResult Function( StripeConnectStateSuccess value)?  success,TResult Function( StripeConnectStateFailure value)?  failure,required TResult orElse(),}){
final _that = this;
switch (_that) {
case StripeConnectStateInitial() when initial != null:
return initial(_that);case StripeConnectStateLoading() when loading != null:
return loading(_that);case StripeConnectStateSuccess() when success != null:
return success(_that);case StripeConnectStateFailure() when failure != null:
return failure(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( StripeConnectStateInitial value)  initial,required TResult Function( StripeConnectStateLoading value)  loading,required TResult Function( StripeConnectStateSuccess value)  success,required TResult Function( StripeConnectStateFailure value)  failure,}){
final _that = this;
switch (_that) {
case StripeConnectStateInitial():
return initial(_that);case StripeConnectStateLoading():
return loading(_that);case StripeConnectStateSuccess():
return success(_that);case StripeConnectStateFailure():
return failure(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( StripeConnectStateInitial value)?  initial,TResult? Function( StripeConnectStateLoading value)?  loading,TResult? Function( StripeConnectStateSuccess value)?  success,TResult? Function( StripeConnectStateFailure value)?  failure,}){
final _that = this;
switch (_that) {
case StripeConnectStateInitial() when initial != null:
return initial(_that);case StripeConnectStateLoading() when loading != null:
return loading(_that);case StripeConnectStateSuccess() when success != null:
return success(_that);case StripeConnectStateFailure() when failure != null:
return failure(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function()?  loading,TResult Function( String url)?  success,TResult Function( Failure failure)?  failure,required TResult orElse(),}) {final _that = this;
switch (_that) {
case StripeConnectStateInitial() when initial != null:
return initial();case StripeConnectStateLoading() when loading != null:
return loading();case StripeConnectStateSuccess() when success != null:
return success(_that.url);case StripeConnectStateFailure() when failure != null:
return failure(_that.failure);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function()  loading,required TResult Function( String url)  success,required TResult Function( Failure failure)  failure,}) {final _that = this;
switch (_that) {
case StripeConnectStateInitial():
return initial();case StripeConnectStateLoading():
return loading();case StripeConnectStateSuccess():
return success(_that.url);case StripeConnectStateFailure():
return failure(_that.failure);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function()?  loading,TResult? Function( String url)?  success,TResult? Function( Failure failure)?  failure,}) {final _that = this;
switch (_that) {
case StripeConnectStateInitial() when initial != null:
return initial();case StripeConnectStateLoading() when loading != null:
return loading();case StripeConnectStateSuccess() when success != null:
return success(_that.url);case StripeConnectStateFailure() when failure != null:
return failure(_that.failure);case _:
  return null;

}
}

}

/// @nodoc


class StripeConnectStateInitial implements StripeConnectState {
  const StripeConnectStateInitial();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is StripeConnectStateInitial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'StripeConnectState.initial()';
}


}




/// @nodoc


class StripeConnectStateLoading implements StripeConnectState {
  const StripeConnectStateLoading();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is StripeConnectStateLoading);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'StripeConnectState.loading()';
}


}




/// @nodoc


class StripeConnectStateSuccess implements StripeConnectState {
  const StripeConnectStateSuccess(this.url);
  

 final  String url;

/// Create a copy of StripeConnectState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$StripeConnectStateSuccessCopyWith<StripeConnectStateSuccess> get copyWith => _$StripeConnectStateSuccessCopyWithImpl<StripeConnectStateSuccess>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is StripeConnectStateSuccess&&(identical(other.url, url) || other.url == url));
}


@override
int get hashCode => Object.hash(runtimeType,url);

@override
String toString() {
  return 'StripeConnectState.success(url: $url)';
}


}

/// @nodoc
abstract mixin class $StripeConnectStateSuccessCopyWith<$Res> implements $StripeConnectStateCopyWith<$Res> {
  factory $StripeConnectStateSuccessCopyWith(StripeConnectStateSuccess value, $Res Function(StripeConnectStateSuccess) _then) = _$StripeConnectStateSuccessCopyWithImpl;
@useResult
$Res call({
 String url
});




}
/// @nodoc
class _$StripeConnectStateSuccessCopyWithImpl<$Res>
    implements $StripeConnectStateSuccessCopyWith<$Res> {
  _$StripeConnectStateSuccessCopyWithImpl(this._self, this._then);

  final StripeConnectStateSuccess _self;
  final $Res Function(StripeConnectStateSuccess) _then;

/// Create a copy of StripeConnectState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? url = null,}) {
  return _then(StripeConnectStateSuccess(
null == url ? _self.url : url // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

/// @nodoc


class StripeConnectStateFailure implements StripeConnectState {
  const StripeConnectStateFailure(this.failure);
  

 final  Failure failure;

/// Create a copy of StripeConnectState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$StripeConnectStateFailureCopyWith<StripeConnectStateFailure> get copyWith => _$StripeConnectStateFailureCopyWithImpl<StripeConnectStateFailure>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is StripeConnectStateFailure&&(identical(other.failure, failure) || other.failure == failure));
}


@override
int get hashCode => Object.hash(runtimeType,failure);

@override
String toString() {
  return 'StripeConnectState.failure(failure: $failure)';
}


}

/// @nodoc
abstract mixin class $StripeConnectStateFailureCopyWith<$Res> implements $StripeConnectStateCopyWith<$Res> {
  factory $StripeConnectStateFailureCopyWith(StripeConnectStateFailure value, $Res Function(StripeConnectStateFailure) _then) = _$StripeConnectStateFailureCopyWithImpl;
@useResult
$Res call({
 Failure failure
});


$FailureCopyWith<$Res> get failure;

}
/// @nodoc
class _$StripeConnectStateFailureCopyWithImpl<$Res>
    implements $StripeConnectStateFailureCopyWith<$Res> {
  _$StripeConnectStateFailureCopyWithImpl(this._self, this._then);

  final StripeConnectStateFailure _self;
  final $Res Function(StripeConnectStateFailure) _then;

/// Create a copy of StripeConnectState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? failure = null,}) {
  return _then(StripeConnectStateFailure(
null == failure ? _self.failure : failure // ignore: cast_nullable_to_non_nullable
as Failure,
  ));
}

/// Create a copy of StripeConnectState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$FailureCopyWith<$Res> get failure {
  
  return $FailureCopyWith<$Res>(_self.failure, (value) {
    return _then(_self.copyWith(failure: value));
  });
}
}

// dart format on
