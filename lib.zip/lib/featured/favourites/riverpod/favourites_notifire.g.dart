// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'favourites_notifire.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(FavouritesNotifire)
final favouritesNotifireProvider = FavouritesNotifireProvider._();

final class FavouritesNotifireProvider
    extends
        $NotifierProvider<FavouritesNotifire, AsyncValue<List<FavoriteModel>>> {
  FavouritesNotifireProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'favouritesNotifireProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$favouritesNotifireHash();

  @$internal
  @override
  FavouritesNotifire create() => FavouritesNotifire();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<List<FavoriteModel>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<List<FavoriteModel>>>(
        value,
      ),
    );
  }
}

String _$favouritesNotifireHash() =>
    r'aad71927404b4e0b4f382329b722bafa9559f25d';

abstract class _$FavouritesNotifire
    extends $Notifier<AsyncValue<List<FavoriteModel>>> {
  AsyncValue<List<FavoriteModel>> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref
            as $Ref<
              AsyncValue<List<FavoriteModel>>,
              AsyncValue<List<FavoriteModel>>
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                AsyncValue<List<FavoriteModel>>,
                AsyncValue<List<FavoriteModel>>
              >,
              AsyncValue<List<FavoriteModel>>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
