// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'data_source_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(authRemoteDataSource)
final authRemoteDataSourceProvider = AuthRemoteDataSourceProvider._();

final class AuthRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          AuthRemoteDataSource,
          AuthRemoteDataSource,
          AuthRemoteDataSource
        >
    with $Provider<AuthRemoteDataSource> {
  AuthRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'authRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$authRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<AuthRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  AuthRemoteDataSource create(Ref ref) {
    return authRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AuthRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AuthRemoteDataSource>(value),
    );
  }
}

String _$authRemoteDataSourceHash() =>
    r'e46a4c634062082389d1492c110461f011d3983b';

@ProviderFor(userRemoteDataSource)
final userRemoteDataSourceProvider = UserRemoteDataSourceProvider._();

final class UserRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          UserRemoteDataSource,
          UserRemoteDataSource,
          UserRemoteDataSource
        >
    with $Provider<UserRemoteDataSource> {
  UserRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'userRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$userRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<UserRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  UserRemoteDataSource create(Ref ref) {
    return userRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(UserRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<UserRemoteDataSource>(value),
    );
  }
}

String _$userRemoteDataSourceHash() =>
    r'7815b441f33877674b5b63caa6df554baf0934dc';

@ProviderFor(notificationAndHistoryRemoteDataSource)
final notificationAndHistoryRemoteDataSourceProvider =
    NotificationAndHistoryRemoteDataSourceProvider._();

final class NotificationAndHistoryRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          NotificationAndHistoryRemoteDataSource,
          NotificationAndHistoryRemoteDataSource,
          NotificationAndHistoryRemoteDataSource
        >
    with $Provider<NotificationAndHistoryRemoteDataSource> {
  NotificationAndHistoryRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'notificationAndHistoryRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() =>
      _$notificationAndHistoryRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<NotificationAndHistoryRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  NotificationAndHistoryRemoteDataSource create(Ref ref) {
    return notificationAndHistoryRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(NotificationAndHistoryRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride:
          $SyncValueProvider<NotificationAndHistoryRemoteDataSource>(value),
    );
  }
}

String _$notificationAndHistoryRemoteDataSourceHash() =>
    r'4c4823d693a81314a3e4dc6bfff46404d04c6a29';

@ProviderFor(serviceRemoteDataSource)
final serviceRemoteDataSourceProvider = ServiceRemoteDataSourceProvider._();

final class ServiceRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          ServiceRemoteDataSource,
          ServiceRemoteDataSource,
          ServiceRemoteDataSource
        >
    with $Provider<ServiceRemoteDataSource> {
  ServiceRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'serviceRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$serviceRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<ServiceRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ServiceRemoteDataSource create(Ref ref) {
    return serviceRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ServiceRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ServiceRemoteDataSource>(value),
    );
  }
}

String _$serviceRemoteDataSourceHash() =>
    r'72ffbf1d13185569f81e5c242d7deb63cc201243';

@ProviderFor(staticContentRemoteDataSource)
final staticContentRemoteDataSourceProvider =
    StaticContentRemoteDataSourceProvider._();

final class StaticContentRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          StaticContentRemoteDataSource,
          StaticContentRemoteDataSource,
          StaticContentRemoteDataSource
        >
    with $Provider<StaticContentRemoteDataSource> {
  StaticContentRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'staticContentRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$staticContentRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<StaticContentRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  StaticContentRemoteDataSource create(Ref ref) {
    return staticContentRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(StaticContentRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<StaticContentRemoteDataSource>(
        value,
      ),
    );
  }
}

String _$staticContentRemoteDataSourceHash() =>
    r'711f3757a4a107e01424f59787c554a1329d7981';

@ProviderFor(paymentDataSource)
final paymentDataSourceProvider = PaymentDataSourceProvider._();

final class PaymentDataSourceProvider
    extends
        $FunctionalProvider<
          PaymentRemoteDataSource,
          PaymentRemoteDataSource,
          PaymentRemoteDataSource
        >
    with $Provider<PaymentRemoteDataSource> {
  PaymentDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'paymentDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$paymentDataSourceHash();

  @$internal
  @override
  $ProviderElement<PaymentRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  PaymentRemoteDataSource create(Ref ref) {
    return paymentDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PaymentRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PaymentRemoteDataSource>(value),
    );
  }
}

String _$paymentDataSourceHash() => r'7cf6463abfe538447afc54e6e691c77b5954b2f9';

@ProviderFor(chatRemoteDataSource)
final chatRemoteDataSourceProvider = ChatRemoteDataSourceProvider._();

final class ChatRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          ChatRemoteDataSource,
          ChatRemoteDataSource,
          ChatRemoteDataSource
        >
    with $Provider<ChatRemoteDataSource> {
  ChatRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'chatRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$chatRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<ChatRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ChatRemoteDataSource create(Ref ref) {
    return chatRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ChatRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ChatRemoteDataSource>(value),
    );
  }
}

String _$chatRemoteDataSourceHash() =>
    r'3cf3806eaaf997989589d37c10504f859cf6d78e';

@ProviderFor(addressRemoteDataSource)
final addressRemoteDataSourceProvider = AddressRemoteDataSourceProvider._();

final class AddressRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          AddressRemoteDataSource,
          AddressRemoteDataSource,
          AddressRemoteDataSource
        >
    with $Provider<AddressRemoteDataSource> {
  AddressRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'addressRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$addressRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<AddressRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  AddressRemoteDataSource create(Ref ref) {
    return addressRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AddressRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AddressRemoteDataSource>(value),
    );
  }
}

String _$addressRemoteDataSourceHash() =>
    r'9ec5da7e4bf75f95285cab7f5920fb21da730454';

@ProviderFor(websiteRemoteDataSource)
final websiteRemoteDataSourceProvider = WebsiteRemoteDataSourceProvider._();

final class WebsiteRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          WebsiteRemoteDataSource,
          WebsiteRemoteDataSource,
          WebsiteRemoteDataSource
        >
    with $Provider<WebsiteRemoteDataSource> {
  WebsiteRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'websiteRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$websiteRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<WebsiteRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  WebsiteRemoteDataSource create(Ref ref) {
    return websiteRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(WebsiteRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<WebsiteRemoteDataSource>(value),
    );
  }
}

String _$websiteRemoteDataSourceHash() =>
    r'6c868579fa9cffd8a72dcd4b3274bf5926c74c5b';
