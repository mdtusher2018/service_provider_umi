// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'website_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(WebsiteNotifier)
final websiteProvider = WebsiteNotifierProvider._();

final class WebsiteNotifierProvider
    extends $NotifierProvider<WebsiteNotifier, AsyncValue<WebsiteState>> {
  WebsiteNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'websiteProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$websiteNotifierHash();

  @$internal
  @override
  WebsiteNotifier create() => WebsiteNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AsyncValue<WebsiteState> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AsyncValue<WebsiteState>>(value),
    );
  }
}

String _$websiteNotifierHash() => r'391720b059f7f0a217e2789629ebee2e9d0d8691';

abstract class _$WebsiteNotifier extends $Notifier<AsyncValue<WebsiteState>> {
  AsyncValue<WebsiteState> build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref =
        this.ref as $Ref<AsyncValue<WebsiteState>, AsyncValue<WebsiteState>>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<WebsiteState>, AsyncValue<WebsiteState>>,
              AsyncValue<WebsiteState>,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
