import 'package:flutter/material.dart';
import 'package:service_provider_umi/core/utils/extensions/num_ext.dart';
import 'package:service_provider_umi/shared/enums/app_enums.dart';
import 'package:service_provider_umi/shared/widgets/app_text.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';

import 'app_avatar.dart';

/// Service provider result card - as seen in search results screen
class ProviderCard extends StatelessWidget {
  final String name;
  final String? imageUrl;

  final double rating;
  final int reviewCount;
  final int serviceCount;
  final double pricePerHour;
  final bool isVerified;
  final bool hasRepeated;
  final bool hasUpdatedSchedule;
  final VoidCallback? onTap;
  final VoidCallback? onFavorite;
  final bool isFavorited;

  const ProviderCard({
    super.key,
    required this.name,
    this.imageUrl,

    required this.rating,
    this.reviewCount = 0,
    this.serviceCount = 0,
    required this.pricePerHour,
    this.isVerified = false,
    this.hasRepeated = false,
    this.hasUpdatedSchedule = false,
    this.onTap,
    this.onFavorite,
    this.isFavorited = true,
  });

  @override
  Widget build(BuildContext context) {
    return _AppCard(
      onTap: onTap,
      padding: 12.paddingAll,
      child: Column(
        children: [
          Row(
            children: [
              AppAvatar(
                imageUrl: imageUrl,
                name: name,
                size: AvatarSize.md,

                isFavorite: Container(
                  padding: 4.paddingAll,
                  decoration: BoxDecoration(
                    color: AppColors.grey300,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    isFavorited ? Icons.favorite : Icons.favorite_border,
                    color: isFavorited ? AppColors.error : AppColors.grey600,
                    size: 16,
                  ),
                ),
              ),
              12.horizontalSpace,
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        AppText(
                          name,
                          style: AppTextStyles.h4,
                          maxLines: 1,
                          color: AppColors.textSecondary,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (isVerified) ...[
                          4.horizontalSpace,
                          const Icon(
                            Icons.verified,
                            color: AppColors.textSecondary,
                            size: 20,
                          ),
                        ],
                      ],
                    ),
                    2.verticalSpace,
                    Row(
                      children: [
                        Icon(Icons.star, color: AppColors.star, size: 20),
                        6.horizontalSpace,
                        AppText.labelMd(
                          '${rating.toStringAsFixed(1)}  (${reviewCount.toString()}) | $serviceCount Services',
                        ),
                      ],
                    ),
                    4.verticalSpace,
                  ],
                ),
              ),
              8.horizontalSpace,
              AppText(
                '\$${pricePerHour.toStringAsFixed(0)}/h',
                style: AppTextStyles.price.copyWith(color: AppColors.secondary),
              ),
            ],
          ),
          8.verticalSpace,
          Row(
            children: [
              if (hasRepeated)
                _buildBadge('$reviewCount has repeated', Icons.sync),
              if (hasRepeated && hasUpdatedSchedule) 6.horizontalSpace,
              if (hasUpdatedSchedule)
                _buildBadge('Updated Schedule', Icons.calendar_today_outlined),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBadge(String text, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: 6.circular,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: AppColors.grey600),
          3.horizontalSpace,
          AppText.bodyXs(
            text,

            color: AppColors.black,
            fontWeight: FontWeight.w500,
          ),
        ],
      ),
    );
  }
}

/// app card container
class _AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final VoidCallback? onTap;

  const _AppCard({required this.child, this.padding, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: 16.circular,
          border: Border.all(color: AppColors.border, width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 12,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: 16.circular,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onTap,
              child: Padding(padding: padding ?? 16.paddingAll, child: child),
            ),
          ),
        ),
      ),
    );
  }
}
