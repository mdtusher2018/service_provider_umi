import 'package:dio/dio.dart';
import 'package:service_provider_umi/core/services/network/api_endpoints.dart';

abstract class AuthRemoteDataSource {
  Future<String> login(String email, String password);
  Future<void> logout();
}

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  final Dio apiService;

  AuthRemoteDataSourceImpl({required this.apiService});

  @override
  Future<String> login(String email, String password) async {
    final response = await apiService.post(
      ApiEndpoints.login,
      data: {'email': email, 'password': password},
    );

    if (response.statusCode == 200 &&
        response.data['data']?['accessToken'] != null) {
      return response.data['token'];
    } else {
      throw Exception(response.data['message'] ?? 'Login failed');
    }
  }

  @override
  Future<void> logout() async {
    await apiService.post('/logout');
  }
}
