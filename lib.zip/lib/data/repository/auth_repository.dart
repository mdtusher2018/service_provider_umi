import 'package:service_provider_umi/core/base/repository.dart';
import 'package:service_provider_umi/core/base/result.dart';
import 'package:service_provider_umi/core/error/failure.dart';
import 'package:service_provider_umi/core/services/storage/local_storage_service.dart';
import 'package:service_provider_umi/core/services/storage/storage_key.dart';
import 'package:service_provider_umi/data/data_source/remote/auth_remote_data_source.dart';

class AuthRepository with SafeCall {
  final AuthRemoteDataSource remote;
  final LocalStorageService local;
  AuthRepository({required this.remote, required this.local});

  Future<Result<String, Failure>> login(String email, String password) async {
    final onlineResult = await asyncGuard(() => remote.login(email, password));

    return onlineResult.when(
      success: (token) async {
        await local.write(StorageKey.accessToken, token);
        return Success(token);
      },
      failure: (failure) async {
        return Error(failure);
      },
    );
  }

  Future<Result<void, Failure>> logout() async {
    await local.clearAll();
    return asyncGuard(() => remote.logout());
  }
}
